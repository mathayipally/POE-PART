import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, FlatList } from 'react-native';

export default function App() {
  const [menuItems, setMenuItems] = useState([]); // Initialize with empty array
  const [showAddScreen, setShowAddScreen] = useState(false);

  const restaurantName = "Christophell's Fine Dining";
  const welcomeNote = "Welcome to Christophells's fine Dining.";

  // Function to add new menu item
  const addMenuItem = (item) => {
    if (item && item.name && item.description && item.price) {  // Validation check
      setMenuItems([...menuItems, item]);  // Add the item if it's valid
      console.log('Added item:', item);    // Log the added item
    } else {
      console.log('Attempted to add an invalid item:', item);  // Log invalid items
    }
    setShowAddScreen(false); // Go back to home screen
  };

  console.log('Menu Items:', menuItems); // Log current menu items

  if (!showAddScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>{restaurantName}</Text>
        <Text>{welcomeNote}</Text>
        <Text style={styles.count}>Total Menu Items: {menuItems.length}</Text>
        
        <Button title="View Menu Item" onPress={() => setShowAddScreen(true)} />

        <FlatList
          data={menuItems}
          renderItem={({ item }) => {
            if (!item) {
              console.log('Undefined item detected');  // Log undefined items
              return null; // Safeguard against undefined items
            }
            return (
              <View style={styles.menuItem}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text>{item.description}</Text>
                <Text>Course: {item.course}</Text>
                <Text>Price: ${item.price}</Text>
              </View>
            );
          }}
          keyExtractor={(item, index) => index.toString()} // Unique key for each item
        />
      </View>
    );
  }

  return <AddMenuItemScreen addMenuItem={addMenuItem} />;
}
const AddMenuItemScreen = ({ addMenuItem }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState('');

  const handleAddItem = () => {
    const newItem = {
      name,
      description,
      price: parseFloat(price), // Ensure price is a number
      course,
    };
    addMenuItem(newItem);
    // Reset the fields
    setName('');
    setDescription('');
    setPrice('');
    setCourse('');
  };

  const AddMenuItemScreen = () => {
  const { addMenuItem } = route.params; 
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState('');

  const handleAddItem = () => {
    const newItem = {
      name,
      description,
      price: parseFloat(price), // Ensure price is a number
      course,
    };
    addMenuItem(newItem);
    // Reset the fields
    setName('');
    setDescription('');
    setPrice('');
    setCourse('');
    navigation.goBack(); // Go back to the main screen after adding item
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Menu Item</Text>
      <TextInput placeholder="Enter Dish Name" value={name} onChangeText={setName} style={styles.input} />
      <TextInput placeholder="Description:" value={description} onChangeText={setDescription} style={styles.input} />
      <TextInput placeholder="Check Price" value={price} onChangeText={setPrice} keyboardType="numeric" style={styles.input} />
      <TextInput placeholder="Main Course: LAmbshank with veggies" value={course} onChangeText={setCourse} style={styles.input} />
      <Button title="Add Item" onPress={handleAddItem} />
    </View>
  );
}; 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  count: {
    fontSize: 18,
    marginVertical: 10,
  },
  menuItem: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
    width: '100%',
  },
  itemName: {
    fontWeight: 'bold',
  });
};